import express from "express";
import subjectRouter from "./routes/subjects/subjectRoute.js"
import sessionRouter from "./routes/sessions/sessionRoute.js"
import analyticsRouter from "./routes/analytics/analyticsRoute.js"
import * as helper from "./helper.js"
import { subjects } from "./data/subjectData.js";
import { sessions } from "./data/sessionData.js";

const ROOT_PATH = "/34057919";
const VIEWS_PATH = `${import.meta.dirname}/views`;
const PORT_NUMBER = 8080;

const app = express();
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true })); // form submissions
app.use('/bootstrap', express.static(`${import.meta.dirname}/node_modules/bootstrap/dist`));
app.use('/images', express.static(`${import.meta.dirname}/public/images`));


//Home Page
app.get(`${ROOT_PATH}/`, (req, res) => {
    const totalSubjects = subjects.length;
    const totalSessions = sessions.length;
    const upcomingSessions = helper.showUpcomingSessions(7)

    res.render("index", {totalSubjects, totalSessions, upcomingSessions});
})

//Subject Page
app.use(`${ROOT_PATH}/subjects`, subjectRouter)

//Session Page
app.use(`${ROOT_PATH}/sessions`, sessionRouter);

//Analytics
app.use(`${ROOT_PATH}/analytics`, analyticsRouter)

//Page not Found
app.use((req, res) => {res.status(404).render("404");});


app.listen(8080);
