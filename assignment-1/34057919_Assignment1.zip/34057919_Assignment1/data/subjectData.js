import * as helper from "../helper.js"

export const createSub = helper.createSubject()

export const SUBJECT_CAT = ["Mathematics", "Computer Science", "Science", "languages", "Business", "Other"]
export const subjects = [
    createSub("Linear Algebra", "Mathematics"),
    createSub("Korean", "Languages", "Introduction to Korean"),
    createSub("Business Math", "Business"),
    createSub("Chemistry", "Science", "Chemistry 101"),
    createSub("Introduction To Programming", "Computer Science", "Introduction to Python"),
]
