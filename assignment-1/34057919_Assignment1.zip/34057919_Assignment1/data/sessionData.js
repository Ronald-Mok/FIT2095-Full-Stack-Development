import * as helper from "../helper.js";

const date = new Date().toISOString().split("T")[0];

export const SCHEDULES = ["scheduled", "completed", "cancelled"];

export const ROLE = ["tutor", "learner"];
export const createSess = helper.createSession();

export const sessions = [
    createSess("SUB-00001", "tutor", "Bob", date, "12:00", 30, ["Matrices", "Eigenvector"], "Cancelled", "", 40),
    createSess("SUB-00001", "learner", "Jeff", date, "12:00", 30, ["Matrices", "Eigenvector"], "Cancelled", "", 40),
    createSess("SUB-00002", "tutor", "Tim", date, "13:00", 60, ["Basic Korean"], undefined, "", 60),
    createSess("SUB-00002", "tutor", "Mark", date, "17:00", 90, ["Advanced Korean"], "Completed", "", 100),
    createSess("SUB-00002", "learner", "Henry", date, "17:00", 90, ["Advanced Korean"], "Completed" ,"", 100),
]
