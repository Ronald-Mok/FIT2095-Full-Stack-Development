import express from "express";
import * as helper from "../../helper.js";

const analyticsRouter = express.Router()

analyticsRouter.get("/", (req, res) => {
    const tutorHours = helper.calcTutorHours().toFixed(1);
    const learnerHours = helper.calcLearnerHours().toFixed(1);
    const subBreakDown = helper.subBreakDown();
    const {upcoming, past} = helper.sessionSchedules()
    const highestTopic = helper.highestTopic()

     res.render("analytics", {tutorHours, learnerHours, subBreakDown, upcoming, past, highestTopic});
});


export default analyticsRouter;
