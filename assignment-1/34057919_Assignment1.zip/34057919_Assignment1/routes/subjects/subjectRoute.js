import express from "express";
import * as helper from "../../helper.js";
import {subjects, createSub, SUBJECT_CAT} from "../../data/subjectData.js"


let tempSub = {name: "", category: "", description: ""};
const subRouter = express.Router()

subRouter.get("/", (req, res) => {
    const reqCat = req.query.category;
    let filteredSub = subjects

    if (reqCat !== "" && reqCat !== undefined) {
        filteredSub = subjects.filter((x) => {return x.category.trim().toLowerCase() === reqCat.trim().toLowerCase()})
    }
    
    res.render("subjects", {subjectList: filteredSub, categories: SUBJECT_CAT, reqCategory: reqCat});
});

subRouter.get("/new", (req, res) => {
    res.render("newSubject", {errObj: "", categories: SUBJECT_CAT, defaultSub: tempSub})
});

subRouter.post("/addNewSubject", (req, res) => {
    const newName = req.body.subName;
    const newCat = req.body.subCategory;
    const newDesc = req.body.subDesc === "" ? undefined : req.body.subDesc;
    const sub_cat_lower = SUBJECT_CAT.map((x) => {return x.trim().toLowerCase()})
    
    tempSub = {name: newName, category: newCat, description: newDesc}

    if (newName.trim() === "") {
        return res.status(400).render("newSubject", {errObj: "Subject Name is required!", categories: SUBJECT_CAT, defaultSub: tempSub});
    }
    
    const isValidName = helper.validSubEntry(subjects, newName)
    const isValidCat = helper.validCatEntry(sub_cat_lower, newCat)
    
    if (!isValidName && !isValidCat) {
        return res.status(400).render("newSubject", {errObj: "Subject Already Exists!\nInvalid Category", categories: SUBJECT_CAT, defaultSub: tempSub})
    } else if (!isValidName) {
        return res.status(400).render("newSubject", {errObj: "Subject Already Exists!", categories: SUBJECT_CAT, defaultSub: tempSub})
    } else if (!isValidCat) {
        return res.status(400).render("newSubject", {errObj: "Invalid Category!", categories: SUBJECT_CAT, defaultSub: tempSub})
    }

    const newSub = createSub(newName, newCat, newDesc);
    subjects.push(newSub)
    tempSub = {name: "", category: "", description: ""};

    res.redirect(".")
})



export default subRouter;

