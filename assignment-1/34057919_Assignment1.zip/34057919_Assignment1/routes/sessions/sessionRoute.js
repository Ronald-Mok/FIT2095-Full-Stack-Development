import express from "express";
import * as helper from "../../helper.js";
import { sessions, createSess, ROLE, SCHEDULES } from "../../data/sessionData.js";
import {subjects, createSub, SUBJECT_CAT} from "../../data/subjectData.js"

const sessRouter = express.Router()

//Session Home Page
sessRouter.get("/", (req, res) => {
    const reqSubjectId = req.query.subjectId;
    const reqRole = req.query.role;
    const reqStatus = req.query.status;
    const reqDateFrom = req.query.dateFrom;
    const reqDateTo = req.query.dateTo;
    let sessionList = sessions;

    if (reqSubjectId) {
        sessionList = sessionList.filter(s => s.subjectId === reqSubjectId);
    }
    if (reqRole) {
        sessionList = sessionList.filter(s => s.role === reqRole);
    }
    if (reqStatus) {
        sessionList = sessionList.filter(s => s.status === reqStatus);
    }
    if (reqDateFrom) {
    sessionList = sessionList.filter(s => s.sessionDate >= reqDateFrom);
    }
    if (reqDateTo) {
        sessionList = sessionList.filter(s => s.sessionDate <= reqDateTo);
    }

    res.render("sessions", {sessionList: sessionList, subjects: subjects, roles: ROLE, reqSubjectId: reqSubjectId, reqRole: reqRole, reqStatus: reqStatus, reqDateFrom: reqDateFrom, reqDateTo: reqDateTo});
})

//Create New Session Page
sessRouter.get("/new", (req, res) => {
    res.render("newSession", {subjects: subjects, roles: ROLE ,errObj: ""})
})

//View Specific Sessions
sessRouter.get("/:sessionId", (req, res) => {
    const session = sessions.find(s => s.sessionId === req.params.sessionId);
    if (!session) {
        return res.status(404).render("404");
    }
    const subject = subjects.find(s => s.subjectId === session.subjectId);
    res.render("sessionDetail", { session: session, subject: subject });
})

//Create New Session Operation
sessRouter.post("/", (req, res) => {
    const subId = req.body.subId
    const role = req.body.role
    const partnerName = req.body.partnerName
    const sessDate = req.body.sessDate
    const srtTime = req.body.startTime
    const topicsCovered = req.body.topicsCovered.split(",").map(topic => topic.trim()).filter(topic => topic !== "");

    const durMins = Number(req.body.durMins)
    const notes = req.body.notes.trim() === "" ? undefined : req.body.notes;
    const rate = req.body.rate === "" ? undefined : Number(req.body.rate);
    
    const validationCheck = helper.isValidSess(subId, role, partnerName, sessDate, srtTime, durMins, topicsCovered, notes, rate)
    if (!validationCheck.check) {
        return res.status(400).render("newSession", {errObj: validationCheck.errors, subjects: subjects, roles: ROLE})
    }

    const newSess = createSess(subId, role, partnerName, sessDate, srtTime, durMins, topicsCovered, undefined, notes, rate)
    sessions.push(newSess)
    res.redirect(".");

});

//Edit Session
sessRouter.get("/edit/:sessId", (req, res) => {
    const session = sessions.find(s => s.sessionId === req.params.sessId);
    if (!session) {
        return res.status(404).render("404");
    }
    res.render("editSession", { session: session, subjects: subjects, roles: ROLE, errObj: [] });
})

sessRouter.post("/edit/:sessId", (req, res) => {
    const session = sessions.find(s => s.sessionId === req.params.sessId);
    if (!session) {
        return res.status(404).render("404");
    }

    if (session.status !== "Scheduled") {
        return res.status(400).render("editSession", {session: session, subjects: subjects, roles: ROLE, errObj: [`This session is already ${session.status} and can no longer be edited.`]});
    }

    
    const subId = req.body.subId
    const role = req.body.role
    const status = req.body.status
    const partnerName = req.body.partnerName
    const sessDate = req.body.sessDate
    const srtTime = req.body.startTime
    const topicsCovered = req.body.topicsCovered.split(",").map(topic => topic.trim()).filter(topic => topic !== "");

    const durMins = Number(req.body.durMins)
    const notes = req.body.notes.trim() === "" ? undefined : req.body.notes;
    const rate = req.body.rate === "" ? undefined : Number(req.body.rate);

    if (!SCHEDULES.includes(status.toLowerCase())) {
        return res.status(400).render("editSession", { session: session, subjects: subjects, roles: ROLE, errObj: ["Invalid status."] });
    }
    const validationCheck = helper.isValidSess(subId, role, partnerName, sessDate, srtTime, durMins, topicsCovered, notes, rate);
    if (!validationCheck.check) {
        return res.status(400).render("editSession", { session: session, subjects: subjects, roles: ROLE, errObj: validationCheck.errors });
    }

    session.subjectId = subId;
    session.role = role;
    session.status = status;
    session.partnerName = partnerName;
    session.sessionDate = sessDate;
    session.startTime = srtTime;
    session.durationMinutes = durMins;
    session.topicsCovered = topicsCovered;
    session.notes = notes;
    session.rate = rate;

    res.redirect(`/34057919/sessions/${session.sessionId}`);
});

sessRouter.get("/delete/:sessId", (req, res) => {
    const session = sessions.find(s => s.sessionId === req.params.sessId);
    if (!session) {
        return res.status(404).render("404");
    }
    res.render("deleteSess", { session: session, errObj: [] });
})

sessRouter.post("/delete/:sessId", (req, res) => {
    const session = sessions.find(s => s.sessionId === req.params.sessId);
    if (!session) {
        return res.status(404).render("404");
    }

    if (session.status === "Completed") {
        return res.status(400).render("deleteSess", {
            session: session,
            errObj: ["Error: Completed sessions cannot be deleted."]
        });
    }

    const index = sessions.findIndex(s => s.sessionId === req.params.sessId);
    sessions.splice(index, 1);

    res.redirect("/34057919/sessions");
});

export default sessRouter;
