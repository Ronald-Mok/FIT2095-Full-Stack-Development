//Subject Helper Functions
//Helper Function to Create subject object
export function createSubject() {
    let subId = 0;
    
    return function (subName, subCat, subDesc="No Description") {
        subId++;
        const date = new Date();
        return { 
            subjectId: `SUB-${subId.toString().padStart(5, '0')}`, 
            name: subName, 
            category: subCat,
            description: subDesc, 
            createdDate: date.toISOString().split("T")[0]}
    }
}

//Check if Existing Subject Name
export function validSubEntry (subArr, newSubName) {
    const valid = subArr.findIndex((p) => p.name.trim().toLowerCase() === newSubName.trim().toLowerCase());
    switch (valid) {
        case -1:
            return true
        default:
            return false
    }
}

//Check if Existing Subject Category
export function validCatEntry (catEnum, newCat) {
    return catEnum.includes(newCat.trim().toLowerCase())
}


//////////////////////////////////////////////////////////////////////////////////////////////////
import {subjects} from "./data/subjectData.js";
import {sessions, ROLE} from "./data/sessionData.js";

//Session Helper Functions
export function createSession() {
    let sessId = 0;
    
    return function (subId, sessRole, partName, sessDate, srtTime, durMins, topCovered, newStatus="Scheduled", sessNotes="No Notes", sessRate=0) {
        sessId++;
        const date = new Date().toISOString().split("T")[0];
        return { 
            sessionId: `SES-${sessId.toString().padStart(5, "0")}`, 
            subjectId: subId, 
            role: sessRole,
            partnerName: partName,
            sessionDate: sessDate,
            startTime: srtTime,
            durationMinutes: durMins,
            topicsCovered: topCovered,
            status: newStatus, //TBC
            notes: sessNotes, 
            rate: sessRate, 
            createdDate: date, //TBC
        }
    }
}

// Session validation check
export function isValidSess(subId, role, partnerName, sessDate, srtTime, durMins, topicsCovered) {
    const errorsArr = [];
    let isValid = true;
    const date = new Date().toISOString().split("T")[0];

    //Check subId
    if (!subjects.some(subject => subject.subjectId === subId)) {
        isValid = false;
        errorsArr.push("Invalid Subject ID")
    } 
    
    //Check role
    if (!ROLE.includes(role)) {
        isValid = false;
        errorsArr.push("Invalid Role")
    }
    
    //Check partnerName
    if (partnerName === undefined || partnerName === "") {
        isValid = false;
        errorsArr.push("Invalid Partner Name")
    }
    
    //Check sessDate
    if (sessDate === undefined || sessDate === "" || sessDate < date) {
        isValid = false;
        errorsArr.push("Invalid Session Date")
    }
    
    //Check srtTime
    if (srtTime === undefined || srtTime === "") {
        isValid = false;
        errorsArr.push("Invalid Start Time")
    }
    
    //Time-conflict check
    if (sessions.includes(sessDate) && sessions) {}
    
    //Dur mins check
    if (durMins < 15 || durMins > 240) {
        isValid = false;
        errorsArr.push("Invalid Duration")
    }
    //Topics Check
    if (topicsCovered.length < 1 || topicsCovered.length > 10) {
        isValid = false;
        errorsArr.push("Invalid Topics")
    }

    return {check: isValid, errors: errorsArr}
}

//Show Session within next n days
export function showUpcomingSessions(n) {
    const today = new Date().toISOString().split("T")[0];
    const nDaysOut = new Date();
    nDaysOut.setDate(nDaysOut.getDate() + n);
    const nDaysOutStr = nDaysOut.toISOString().split("T")[0];

    const upcomingSessions = sessions.filter(s =>s.status === "Scheduled" && s.sessionDate >= today && s.sessionDate <= nDaysOutStr).length;

    return upcomingSessions
}


//////////////////////////////////////////////////////////////////////////////////////////////////
//Analytics Helper Functions
export function calcTutorHours() {
    let tutorMins = 0;
    const completedSess = sessions.filter(s => s.status === "Completed" && s.role === "tutor");
    completedSess.forEach(s => {
        tutorMins += s.durationMinutes;
    })

    const tutorHour = tutorMins/60

    return tutorHour;
}

export function calcLearnerHours() {
    let learnerMins = 0;
    const completedSess = sessions.filter(s => s.status === "Completed" && s.role === "learner");
    completedSess.forEach(s => {
        learnerMins += s.durationMinutes;
    })

    const learnerHour = learnerMins/60

    return learnerHour;
}

export function subBreakDown() {
    const completedSess = sessions.filter(s => s.status === "Completed");
    const subMap = new Map();
    let subMins = 0;

    completedSess.forEach(s => {
        subMap.set(s.subjectId, (subMap.get(s.subjectId) || 0) + s.durationMinutes)
    })

    const subBreakDown = [...subMap.entries()].map(([subjectId, totalMinutes]) => ({
        subjectName: subjects.find(sub => sub.subjectId === subjectId).name,
        totalMinutes: totalMinutes
    }))
    
    subBreakDown.sort((a, b) => b.totalMinutes - a.totalMinutes);

    return subBreakDown
}

export function sessionSchedules() {
    const currDay = new Date().toISOString().split("T")[0];

    const upcoming = sessions.filter(s => s.status === "Scheduled" && s.sessionDate > currDay);
    const past = sessions.filter(s => s.sessionDate <= currDay);

    return { upcoming, past };
}


export function highestTopic() {
    const topicCounts = new Map();

    sessions.forEach(s => {
        s.topicsCovered.forEach(topic => {
            topicCounts.set(topic, (topicCounts.get(topic) || 0) + 1);
        });
    });

    let topTopic;
    let topCount = 0;

    topicCounts.forEach((count, topic) => {
        if (count > topCount) {
            topCount = count;
            topTopic = topic;
        }
    });

    return topTopic;
}

