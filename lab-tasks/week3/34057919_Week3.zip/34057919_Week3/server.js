import http from "node:http";
import { readFile } from "node:fs/promises";

const server = http.createServer(async (request, response) => {
  const url = new URL(request.url, `http://${request.headers.host}`);

  if (url.pathname === "/") {
    const indexPage = await readFile("./views/index.html", "utf-8");

    response.writeHead(200, { "Content-Type": "text/html" });
    response.end(indexPage);
    return;
  }

  if (url.pathname === "/about") {
    const aboutPage = await readFile("./views/about.html", "utf-8");

    response.writeHead(200, { "Content-Type": "text/html" });
    response.end(aboutPage);
    return;
  }

  if (url.pathname === "/contact") {
    const contact = await readFile("./contact.json", "utf-8");

    response.writeHead(200, { "Content-Type": "application/json" });
    response.end(contact);
    return;
  }
  response.writeHead(404, { "Content-Type": "text/plain" });
  response.end("404 Not found");

});

server.listen(8080);
